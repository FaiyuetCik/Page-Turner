# Corresponding dependency source snapshot

This archive preserves the actual installed sources used for the Page Turner build:

- Seeed nRF52 Boards 1.1.13: nRF5 core, Plus board variant, board/platform recipes, and the seven libraries used by this build.
- Seeed_GFX2 1.0.0: complete library source directory and its original license.
- Original package and source-file copyright/license notices.

These dependencies have not been edited or relicensed by the Page Turner project. Some directories include unused headers or examples; inclusion here does not mean they are linked into the application.

The main application source and rebuild instructions are in the accompanying Page Turner repository / firmware ZIP. Install the matching BSP and its tool dependencies through Arduino Board Manager; the compiler, CMSIS tool package, nrfutil, bootloader and SoftDevice are not replaced by this archive.

To rebuild with modified LGPL library code, back up the installed BSP and overlay this archive's `Seeed-nRF52-1.1.13/cores`, `libraries` and matching board variant into the installed BSP 1.1.13. Make your changes there. Install `Seeed_GFX2-1.0.0` as an Arduino library. Build the supplied application normally, which recompiles and relinks the application with the modified libraries. The application's MIT terms permit these modifications and relinking; no additional restriction is imposed on debugging modifications to LGPL components. Nordic/Arm-specific components retain their own hardware restrictions.