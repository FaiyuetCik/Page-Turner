/**************************************************************************/
/*!
    @file     debug.h
    @author   hathach (tinyusb.org)

    @section LICENSE

    Software License Agreement (BSD License)

    Copyright (c) 2018, Adafruit Industries (adafruit.com)
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holders nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**************************************************************************/

#ifndef _DEBUG_H
#define _DEBUG_H

#include "common_inc.h"

#ifdef __cplusplus
 extern "C" {
#endif

#if CFG_DEBUG
const char* dbg_ble_event_str(uint16_t evt_id);
const char* dbg_err_str(int32_t err_id);
const char* dbg_hci_str(uint8_t id);
#endif

int dbgHeapTotal(void);
int dbgHeapUsed(void);

int dbgStackTotal(void);
int dbgStackUsed(void);

static inline int dbgHeapFree(void)
{
  return dbgHeapTotal() - dbgHeapUsed();
}

void dbgMemInfo(void);
void dbgPrintVersion(void);
void dbgDumpMemory(void const *buf, uint8_t size, uint16_t count, bool printOffset);
void dbgDumpMemoryCFormat(const char* str, void const *buf, uint16_t count);

#ifdef __cplusplus
 }
#endif

#endif
